import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-product-card',
  imports: [CommonModule],
  templateUrl: './product-card.component.html',
  styleUrl: './product-card.component.css',
})
export class ProductCardComponent {
  @Input() product: any;
  @Output() delete = new EventEmitter<string>();

  onDelete(): void {
    console.log('Producto a eliminar:', this.product);
    this.delete.emit(this.product._id);
  }
}
