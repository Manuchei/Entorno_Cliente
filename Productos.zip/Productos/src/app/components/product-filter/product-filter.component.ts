import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-product-filter',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './product-filter.component.html',
  styleUrl: './product-filter.component.css',
})
export class ProductFilterComponent {
  @Output() filter = new EventEmitter<any>();

  filterCriteria = {
    name: '',
    category: '',
    price: null,
    active: null,
  };

  onFilter(): void {
    this.filter.emit(this.filterCriteria);
  }
}
