import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private apiUrl = 'https://jsonblob.com/api/1330882149766848512'; // URL proporcionada por ti

  constructor(private http: HttpClient) {}

  getProducts(): Observable<any[]> {
    console.log('Llamando a la API:', this.apiUrl); // Confirmar que se realiza la llamada
    return this.http.get<any[]>(this.apiUrl);
  }
  
  

  addProduct(product: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, product);
  }

  deleteProduct(id: string): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${id}`);
  }
}
