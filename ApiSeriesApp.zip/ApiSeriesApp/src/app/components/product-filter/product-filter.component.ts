import { Component } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  selector: 'app-product-filter',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './product-filter.component.html',
  styleUrls: ['./product-filter.component.css'],
})
export class ProductFilterComponent {
  filterForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.filterForm = this.fb.group({
      name: [''],
      category: [''],
      minPrice: [0],
      maxPrice: [Infinity],
      active: [null],
    });
  }

  applyFilter(): void {
    const filters = this.filterForm.value;
    console.log('Filters applied:', filters);
    // Aquí podrías emitir un evento o aplicar los filtros a tu lógica
  }
}
