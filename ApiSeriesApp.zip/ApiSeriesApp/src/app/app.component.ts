import { HttpClientModule } from '@angular/common/http'
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductFilterComponent } from './components/product-filter/product-filter.component';
import { ProductCardComponent } from './components/product-card/product-card.component';
import { Product } from './models/Product';
import { ProductService } from './services/product.service';
import { ReactiveFormsModule } from '@angular/forms';


@Component({
  standalone: true,
  selector: 'app-root',
  imports: [CommonModule, ProductFilterComponent, ProductCardComponent, HttpClientModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  products: Product[] = []; // Lista de productos inicial
  filteredProducts: Product[] = []; // Lista de productos filtrados

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.productService.getProducts();
    this.productService.products$.subscribe((products) => {
      this.products = products;
      this.filteredProducts = [...this.products];
    });
  }

  filterProducts(filters: any): void {
    this.filteredProducts = this.products.filter((product) => {
      return (
        (!filters.name || product.name.toLowerCase().includes(filters.name.toLowerCase())) &&
        (!filters.category || product.category === filters.category) &&
        (product.price >= (filters.minPrice || 0)) &&
        (product.price <= (filters.maxPrice || Infinity)) &&
        (filters.active === null || product.active === filters.active)
      );
    });
  }
}
