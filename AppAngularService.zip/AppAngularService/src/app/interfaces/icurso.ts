export interface ICurso {
    titulo: string;
    valor: string;
}
