import { ICurso } from "../interfaces/icurso";

export const CURSOS: ICurso[] = [
    { titulo: '1 ESO', valor: '1ESO' },
    { titulo: '2 ESO', valor: '2ESO' },
    { titulo: '3 ESO', valor: '3ESO' },
    { titulo: '4 ESO', valor: '4ESO' },
    { titulo: '5 ESO', valor: '5ESO' },
    { titulo: '6 ESO', valor: '6ESO' },
    { titulo: '7 ESO', valor: '7ESO' }
];