import { Component } from '@angular/core';

@Component({
  selector: 'app-student-form',
  imports: [],
  templateUrl: './student-form.component.html',
  styleUrl: './student-form.component.css'
})
export class StudentFormComponent {

}
