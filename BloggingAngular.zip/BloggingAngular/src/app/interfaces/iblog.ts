export interface Iblog {
  titulo: string;
  imagen: string;
  texto: string;
  fecha_publicacion: string;
}
