var productos = [];

document.addEventListener('DOMContentLoaded', function (event) {
    
    function cargarTabla(productos) {
        const tablaProducts = document.getElementById("tablaProductos");

        productos.forEach(producto => {
            const userId = document.createElement('td');
            userId.innerText = producto.id;  

            const name = document.createElement('td');
            const parr = document.createElement('p');

            const miDiv = document.createElement('div');
            const miButton = document.createElement('button');
            miButton.textContent = "Check";
            parr.textContent = producto.name + "  :  " + producto.username;  
            miDiv.append(parr, miButton);

            name.appendChild(miDiv);

            miButton.addEventListener('click', function (event) {
                alert("He pulsado el botón " + producto.username);  
            });

            const username = document.createElement('td');
            username.innerText = producto.username;  

            const email = document.createElement('td');
            email.innerText = producto.email;  

            const tr = document.createElement('tr');
            tr.append(userId, name, username, email);

            tablaProducts.append(tr);
        });
    }

    fetch('https://jsonblob.com/api/1298679055254413312')
        .then(response => response.json())
        .then(data => {
            productos = data;  
            cargarTabla(productos);  
        });
});
