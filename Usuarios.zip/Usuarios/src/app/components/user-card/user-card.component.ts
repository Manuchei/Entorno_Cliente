import { UsersService } from './../../services/users.service';
import { User } from './../../interfaces/user';
import { Component, inject, Input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { BotoneraComponent } from "../botonera/botonera.component";

@Component({
  selector: 'app-user-card',
  imports: [BotoneraComponent],
  templateUrl: './user-card.component.html',
  styleUrl: './user-card.component.css'
})
export class UserCardComponent {

  @Input() miUsuario!: User



}
